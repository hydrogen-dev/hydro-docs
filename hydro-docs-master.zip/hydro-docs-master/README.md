# Project Hydro Documentation
<p>API Documentation for Project Hydro - The Fintech Blockchain</p>
<img src="https://www.hydrogenplatform.com/images/logo_hydro.png">

<H3>Hydro API docs have been <a href="https://www.hydrogenplatform.com/docs/hydro/v1" target="_blank">moved here</a></H3>
